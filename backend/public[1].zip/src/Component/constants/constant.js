module.exports = {
  baseUrl: 'https://eventhub-backend.onrender.com/api/v1',
}