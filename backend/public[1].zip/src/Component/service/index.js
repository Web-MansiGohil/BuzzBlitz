import { baseUrl } from "../constants/constant";
import server from "../utils/interceptors/interceptors";
import { getToken } from "../utils/localstorage/token";

const User_Token = getToken();

const postRequest = async (path, payload) => {
    const AXIOS_CONFIG = {
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    };
    const API_ENDPOINT = `${baseUrl}${path}`;
    return await server.post(API_ENDPOINT, payload, AXIOS_CONFIG);
}

const postRequestWithToken = async (path, payload) => {
  const AXIOS_CONFIG = {
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json",
      Authorization: User_Token,
    },
  };
  const API_ENDPOINT = `${baseUrl}${path}`;
  return await server.post(API_ENDPOINT, payload, AXIOS_CONFIG);
};

export {
    postRequest,
    postRequestWithToken,
}