import { postRequest } from '.';
import Toast from '../utils/toast';

const Register = async payload => {
    try {
        const registerpath = `/register`;
        return await postRequest(registerpath, payload);
    } catch (error) {
        Toast('error', error?.response?.data?.message);
    }
}

const Login = async payload => {
    try {
        const loginpath = `/login`;
        return await postRequest(loginpath, payload);
    } catch (error) {
        Toast('error', error?.response?.data?.message);
    }
}

export const authService = {
    Register,
    Login
}
