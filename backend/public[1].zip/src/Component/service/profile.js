import { postRequestWithToken } from ".";
import Toast from "../utils/toast";

const Profile =async payload=>{
    try {
        const profilepath =`/user_detail`;
        return await postRequestWithToken(profilepath,payload);
    } catch (error) {
        Toast('error',error?.response?.data?.message);
    }
}

export const profileService = {
    Profile,
}