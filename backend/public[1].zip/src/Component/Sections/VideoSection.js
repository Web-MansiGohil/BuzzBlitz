// VideoSection.jsx
import React from 'react';

const VideoSection = () => {
  return (
    <section className="relative w-full min-h-[400px] flex items-center justify-center overflow-hidden bg-black">
      {/* Parallax Background */}
      <div
        className="absolute inset-0 bg-cover bg-center transform scale-110 translate-y-[-50px] transition-all duration-500 will-change-transform"
        style={{
          backgroundImage: 'url(https://i.ytimg.com/vi/t-CObf5f5Z8/maxresdefault.jpg)', // fallback image
          zIndex: 1,
        }}
      ></div>

      {/* Overlay or darker effect if needed */}
      <div className="absolute inset-0 bg-black bg-opacity-40 z-10"></div>

      {/* Play Button */}
      <div className="relative z-20 text-center">
        <a
          href="https://www.youtube.com/watch?v=t-CObf5f5Z8"
          target="_blank"
          rel="noopener noreferrer"
          className="group inline-flex items-center justify-center w-20 h-20 rounded-full bg-white bg-opacity-80 hover:bg-opacity-100 transition duration-300"
        >
          <svg
            className="w-8 h-8 text-black group-hover:scale-110 transition-transform duration-200"
            fill="currentColor"
            viewBox="0 0 24 24"
          >
            <path d="M8 5v14l11-7z" />
          </svg>
        </a>
      </div>
    </section>
  );
};

export default VideoSection;
