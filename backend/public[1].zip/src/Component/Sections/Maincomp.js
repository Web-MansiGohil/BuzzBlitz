import Button from "../../Components/ui/button";

export default function MarketingSummitFullSection() {
  return (
    <section className="relative w-full bg-transparent overflow-visible">
      <div className="absolute inset-0 bg-black/0 pointer-events-none" /> {/* Background overlay */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col gap-8">
          {/* Inner Section */}
          <div className="flex flex-col md:flex-row gap-8 py-12">
            {/* Left Column */}
            <div className="flex-1 flex flex-col gap-6">
              <h3 className="text-2xl font-semibold text-purple-700">
                Explore Excellence in
              </h3>
              <img
                src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/contact-us-img-1.png"
                alt="Contact Us"
                width={172}
                height={63}
                className="mb-2"
              />
              <h3 className="text-2xl font-bold text-indigo-600">
                Marketing Summit 2024
              </h3>
              <ul className="space-y-2">
                <li>
                  <div className="flex items-center gap-3">
                    <span className="font-medium">20 - 25</span>
                    <span className="text-gray-500">February, 2024</span>
                  </div>
                </li>
                <li>
                  <div className="flex items-center gap-3">
                    <span className="font-medium">Minere Arena Banquet Hall</span>
                    <span className="text-gray-500">
                      23rd Avenue, 4th Street, Chicago, Illinois, USA
                    </span>
                  </div>
                </li>
              </ul>
              <Button asChild className="w-fit mt-4">
                <a
                  href="https://demo.bravisthemes.com/festiva/get-ticket/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Purchase Ticket
                </a>
              </Button>
            </div>
            {/* Right Column */}
            <div className="flex-1 flex flex-col gap-8 relative">
              {/* Interactive Session */}
              <div className="flex items-center gap-4 bg-white rounded-lg shadow p-4">
                <img
                  src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/gj-3-730x878.png"
                  alt="gj 3"
                  width={120}
                  height={144}
                  className="rounded"
                />
                <div>
                  <img
                    src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-signature-1.png"
                    alt="Signature"
                    width={180}
                    height={80}
                    className="mb-2"
                  />
                  <h5 className="text-sm font-semibold text-purple-700">
                    INTERACTIVE SESSION
                  </h5>
                </div>
              </div>
              {/* Guest Speaker */}
              <div className="flex items-center gap-4 bg-white rounded-lg shadow p-4 absolute top-0 right-0 md:static">
                <div>
                  <img
                    src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-Jason-miler.svg"
                    alt="Jason Miler"
                    width={120}
                    height={44}
                    className="mb-2"
                  />
                  <h5 className="text-sm font-semibold text-indigo-600">
                    GUEST SPEAKER
                  </h5>
                </div>
              </div>
              {/* Contact Email */}
              <div className="absolute left-0 bottom-20 md:static">
                <a
                  href="mailto:festivaevent@gmail.com"
                  className="text-blue-600 underline"
                >
                  festivaevent@gmail.com
                </a>
              </div>
              {/* Social Icons */}
              <div className="flex gap-4 items-center absolute left-0 bottom-0 md:static">
                <a href="#" aria-label="Facebook">
                  <i className="fab fa-facebook-f text-xl text-blue-700"></i>
                </a>
                <a href="#" aria-label="Instagram">
                  <i className="fab fa-instagram text-xl text-pink-500"></i>
                </a>
                <a href="#" aria-label="Twitter">
                  <i className="fab fa-twitter text-xl text-blue-400"></i>
                </a>
                <a href="#" aria-label="LinkedIn">
                  <i className="fab fa-linkedin-in text-xl text-blue-800"></i>
                </a>
                <a href="#" aria-label="YouTube">
                  <i className="fab fa-youtube text-xl text-red-600"></i>
                </a>
              </div>
              {/* SVG Decorative Icon */}
              <div className="absolute top-0 left-0">
                <svg xmlns="http://www.w3.org/2000/svg" width="122" height="121" viewBox="0 0 122 121" fill="none">
                  <g clipPath="url(#clip0_5125_583)">
                    <path d="M120.563 96.2149C120.674 95.7911 120.009 95.6301 119.899 96.0539C116.861 107.515 105.195 113.675 94.2937 115.74C82.5729 117.962 69.5014 116.449 59.6237 109.389C57.4577 107.84 55.4088 105.808 53.6563 103.496C57.0747 103.672 60.5197 103.105 63.8522 101.552C69.1354 99.0902 73.3236 94.2466 73.685 88.2753C73.9986 83.1628 71.6203 77.6379 66.8821 75.2767C62.1271 72.9078 56.5015 74.4153 52.5782 77.6762C47.8108 81.6389 46.0427 87.7109 47.2159 93.726C47.773 96.5778 48.7918 99.16 50.1574 101.492C43.3025 100.004 36.7148 95.6629 32.169 90.699C26.3955 84.4042 22.5289 76.0395 21.9867 67.4743C26.6876 70.5044 31.9104 72.5375 37.3325 72.9982C49.4168 74.0384 59.7025 60.476 53.1484 49.4154C46.7684 38.6544 32.0864 39.2024 25.2465 48.9908C22.0083 53.624 20.5322 59.0029 20.4362 64.488C13.6821 59.5586 8.30919 52.6167 5.24022 44.9944C0.323296 32.746 1.7021 18.7965 8.02258 7.39161C8.66666 10.6612 8.93163 13.9341 8.82899 17.3173C8.8003 18.2662 10.2661 18.2131 10.3033 17.2722C10.4282 13.2701 10.0295 9.39944 9.12796 5.52768C9.35598 5.16622 9.56702 4.78879 9.80353 4.43532C10.2606 3.74535 9.13049 2.91431 8.62327 3.58108C8.54394 3.68243 8.47282 3.78353 8.39348 3.88488C8.12665 3.78587 7.79796 3.82066 7.59911 4.05757C5.06221 7.09468 2.83534 10.2954 0.871336 13.7355C0.464219 14.4404 1.5364 15.265 2.05159 14.5897C2.82826 13.5685 3.61316 12.5469 4.38982 11.5257C-0.300415 22.8642 -0.494713 35.9202 4.61763 47.2805C7.87219 54.5014 13.5199 61.5338 20.4544 66.433C20.7548 74.0988 23.6207 81.818 27.9855 87.8757C33.2882 95.2154 42.0481 101.848 51.2915 103.263C58.351 113.327 72.3693 118.035 84.3375 117.974C98.7698 117.887 116.544 111.704 120.563 96.2149ZM22.764 58.1185C24.2443 52.0717 28.0031 45.8563 34.083 43.5682C39.4701 41.5404 45.8255 43.407 49.7905 47.4406C54.1806 51.8982 54.729 58.5094 51.7198 63.894C48.0074 70.5449 41 72.6965 33.8215 70.8715C29.5843 69.7975 25.5703 67.9335 21.918 65.4979C21.9085 63.0332 22.1707 60.5521 22.764 58.1185ZM55.6662 77.2932C61.4423 73.9674 68.4721 75.7804 71.1626 82.0789C73.7816 88.1981 71.362 94.8012 66.0532 98.5826C61.8738 101.555 57.1851 102.432 52.527 101.882C47.1835 93.7435 45.7664 82.9874 55.6662 77.2932Z" fill="#9740C0"></path>
                  </g>
                  <defs>
                    <clipPath id="clip0_5125_583">
                      <rect width="116.901" height="117.692" fill="white" transform="translate(117.637) rotate(88.2484)" />
                    </clipPath>
                  </defs>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
