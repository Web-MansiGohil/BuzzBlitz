// src/components/PartnerCarousel.jsx
import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";

// Import Swiper styles
import "swiper/css";

const partners = [
  {
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-partner-cr-1.png",
    alt: "Media Partner",
    industry: "Media",
    position: "PARTNER",
  },
  {
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-partner-cr-2.png",
    alt: "Print Partner",
    industry: "Print",
    position: "PARTNER",
  },
  {
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-partner-cr-3.png",
    alt: "Event Partner",
    industry: "Event",
    position: "PARTNER",
  },
  {
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-partner-cr-4.png",
    alt: "Telco Partner",
    industry: "Telco",
    position: "PARTNER",
  },
  {
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-partner-cr-5.png",
    alt: "Marketing Partner",
    industry: "Marketing",
    position: "PARTNER",
  },
  {
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-partner-cr-6.png",
    alt: "Event Partner Small",
    industry: "Event",
    position: "PARTNER",
  },
];

const PartnerCarousel = () => {
  return (
    <section className="elementor-section pxl-row-scroll-none pxl-section-overflow-visible pxl-bg-color-none pxl-section-overlay-none">
      <div className="elementor-container elementor-column-gap-extended">
        <div className="elementor-column elementor-col-100 pxl-column-none pxl-column-overflow-hidden-no">
          <div className="elementor-widget-wrap">
            {/* Logo Image */}
            <div className="elementor-widget">
              <div className="elementor-widget-container">
                <div className="pxl-image-single style-default style-hover-style-1">
                  <div className="pxl-item--inner">
                    <div className="pxl-item--image">
                      <img
                        src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-light.png"
                        width={218}
                        height={80}
                        alt="logo"
                        loading="eager"
                        className="no-lazyload"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Heading */}
            <div className="elementor-widget">
              <div className="elementor-widget-container">
                <div className="pxl-heading pxl-heading--tcustom">
                  <div className="pxl-heading--inner">
                    <h3 className="pxl-item--title pxl-color-style-1 wow fadeInUp">
                      Partners who <br />
                      collaborate with us
                    </h3>
                  </div>
                </div>
              </div>
            </div>

            {/* Swiper Partner Carousel */}
            <div className="elementor-widget">
              <div className="elementor-widget-container">
                <div className="pxl-swiper-sliders pxl-partner-carousel pxl-partner-carousel2">
                  <Swiper
                    modules={[Autoplay]}
                    slidesPerView={6}
                    spaceBetween={20}
                    loop={true}
                    autoplay={{
                      delay: 5000,
                      disableOnInteraction: false,
                    }}
                    breakpoints={{
                      1200: { slidesPerView: 6 },
                      1024: { slidesPerView: 4 },
                      768: { slidesPerView: 3 },
                      640: { slidesPerView: 3 },
                      320: { slidesPerView: 2 },
                    }}
                    className="pxl-swiper-container"
                  >
                    {partners.map((partner, idx) => (
                      <SwiperSlide key={idx} className="pxl-swiper-slide">
                        <div className="pxl-item--inner">
                          <div className="pxl-item--logo">
                            <a href="#">
                              <img
                                src={partner.img}
                                alt={partner.alt}
                                width={135}
                                height={131}
                                className="no-lazyload"
                                loading="eager"
                              />
                            </a>
                          </div>
                          <div className="pxl-item-industry">{partner.industry}</div>
                          <div className="pxl-item-position">{partner.position}</div>
                        </div>
                      </SwiperSlide>
                    ))}
                  </Swiper>
                </div>
              </div>
            </div>
            {/* / End Swiper */}
          </div>
        </div>
      </div>
    </section>
  );
};

export default PartnerCarousel;
