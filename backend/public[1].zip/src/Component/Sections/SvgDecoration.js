const SVGDecorations = () => (
  <>
    <svg
      className="absolute -top-5 left-0 w-40 h-40 opacity-50 z-0"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 374 399"
      fill="none"
    >
      <path
        d="M232.116 14.42C287.115 40.4478 339.435 125.941 358.72 165.435C395.116 242.348 366.017 336.234 272.177 380.056C178.336 423.878 78.5518 385.364 29.978 315.75C-18.5958 246.136 -3.16069 138.966 44.0135 74.0889C91.1877 9.21171 163.366 -18.1146 232.116 14.42Z"
        fill="url(#gradient1)"
        fillOpacity="0.5"
      />
      <defs>
        <linearGradient id="gradient1" x1="3.37258" y1="174.362" x2="376.055" y2="228.037" gradientUnits="userSpaceOnUse">
          <stop stopColor="#CF134C" />
          <stop offset="1" stopColor="#870970" />
        </linearGradient>
      </defs>
    </svg>
    <svg
      className="absolute bottom-0 right-0 w-40 h-40 opacity-40 z-0"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 390 364"
      fill="none"
    >
      <path
        d="M8.5364 205.548C28.6088 260.841 107.076 319.177 143.801 341.434C215.436 383.662 310.059 364.577 362.065 278.57
         C414.07 192.564 386.167 93.069 322.857 39.8315C259.548 -13.4061 153.272 -8.70203 85.2407 30.4868
         C17.2098 69.6756 -16.5541 136.432 8.5364 205.548Z"
        fill="url(#gradient2)"
        opacity="0.6"
      />
      <defs>
        <linearGradient id="gradient2" x1="187.236" y1="0.917583" x2="203.307" y2="364" gradientUnits="userSpaceOnUse">
          <stop stopColor="#E100A8" />
          <stop offset="1" stopColor="#71009C" />
        </linearGradient>
      </defs>
    </svg>
  </>
);
export default SVGDecorations;