import Button from "../../Components/ui/button";


export default function ExploreUsSection() {
  return (
    <section className="relative w-full bg-transparent overflow-visible">
      {/* Vertical Divider Lines (optional, can be improved with SVG or absolute divs) */}
      <div className="absolute inset-y-0 left-1/2 w-px bg-gradient-to-b from-purple-400 via-transparent to-purple-400 opacity-20 pointer-events-none" />

      <div className="container mx-auto px-4 py-16 flex flex-col md:flex-row gap-12 items-center">
        {/* Left Image Box */}
        <div className="md:w-1/2 flex flex-col items-center">
          <div className="relative">
            <img
              src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/home-1-image-1-1-550x785.png"
              alt="home-1-image-1"
              width={350}
              height={500}
              className="rounded-xl shadow-lg object-cover"
            />
            <div className="absolute bottom-4 left-4 bg-white/80 px-4 py-2 rounded">
              <h5 className="text-xs font-bold tracking-widest text-purple-600">SUMMIT</h5>
              <a
                href="https://demo.bravisthemes.com/festiva/about-us/"
                className="text-sm text-blue-600 hover:underline"
              >
                Marketing Summit 2024
              </a>
            </div>
          </div>
        </div>

        {/* Right Content */}
        <div className="md:w-1/2 flex flex-col gap-6">
          <div>
            <h3 className="text-2xl font-bold text-purple-700 mb-2">ABOUT EVENT</h3>
            <img
              src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-light.png"
              alt="logo"
              width={120}
              height={40}
              className="mb-2"
            />
            <h3 className="text-3xl font-extrabold text-gray-900 mb-2">
              Explore Amazing... <span className="text-gradient bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Marketing Ideas</span>
            </h3>
            <p className="text-gray-700 mb-4">
              Like previous year this year we are arranging world marketing summit 2024. It's the gathering of all the big and amazing marketing & branding minds from all over the world. Discussing the best techniques for branding to deep dive into consumers mind. Will try to spread best knowledge about marketing.
            </p>
            <Button asChild className="mt-2">
              <a
                href="https://demo.bravisthemes.com/festiva/about-us/"
                className="flex items-center gap-2"
              >
                Explore Us
                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
                  <path d="M4.75 15.0417L15.0417 4.75M15.0417 4.75V14.63M15.0417 4.75H5.16167" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </a>
            </Button>
          </div>
          {/* Decorative absolute image */}
          <img
            src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-dust.png"
            alt=""
            width={400}
            height={150}
            className="absolute bottom-0 right-0 opacity-30 pointer-events-none"
            style={{ zIndex: -1 }}
          />
        </div>
      </div>

      {/* Why Join Section */}
      <div className="container mx-auto px-4 py-8">
        <h3 className="text-2xl font-bold text-purple-700 mb-8">
          Why You Should Join <br /> The Event?
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Card 1 */}
          <div className="bg-white rounded-lg shadow p-6 flex flex-col items-center text-center">
            {/* SVG Icon */}
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="none" className="mb-4">
              {/* ... SVG PATHS ... */}
              <circle cx="15" cy="15" r="14" stroke="#8C5BF4" strokeWidth="2" />
            </svg>
            <h5 className="font-bold text-lg mb-2 bg-gradient-to-r from-purple-500 to-pink-500 text-transparent bg-clip-text">Startup Community</h5>
            <p className="text-gray-600 mb-2">
              You will get the big opportunity to interact & communicate with best startups around the world.
            </p>
            <a href="https://demo.bravisthemes.com/festiva/event/event/" className="text-blue-600 hover:underline flex items-center gap-1">
              Read More
              <span>&rarr;</span>
            </a>
          </div>
          {/* ...Repeat for other cards... */}
        </div>
      </div>
    </section>
  );
}
