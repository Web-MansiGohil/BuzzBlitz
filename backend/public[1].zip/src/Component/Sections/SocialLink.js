const SocialLinks = () => (
  <div className="mt-3 flex justify-center space-x-4 text-gray-500">
    <a href="#" target="_blank" rel="noreferrer noopener" className="hover:text-blue-600">
      <i className="fab fa-facebook-f"></i>
    </a>
    <a href="#" target="_blank" rel="noreferrer noopener" className="hover:text-pink-500">
      <i className="fab fa-instagram"></i>
    </a>
    <a href="#" target="_blank" rel="noreferrer noopener" className="hover:text-blue-400">
      <i className="fab fa-twitter"></i>
    </a>
    <a href="#" target="_blank" rel="noreferrer noopener" className="hover:text-blue-700">
      <i className="fab fa-linkedin-in"></i>
    </a>
  </div>
);
export default SocialLinks;