import React from "react";

const EventCard2 = () => (
  <div className="pxl-grid-item col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" style={{ position: "absolute", left: "0%", top: "976.4px" }}>
    <div className="pxl-item--holder style-layout--1">
      <div className="pxl-item--featured">
        <a href="https://demo.bravisthemes.com/festiva/event/event/">
          {/* Image is inside the <a> */}
          <img
            decoding="async"
            className="no-lazyload"
            src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/07/home-tab-event-1-scaled-441x374.webp"
            width={441}
            height={374}
            alt="home-tab-event-1"
            title="home-tab-event-1"
          />
        </a>
        <div className="pxl-btn-category">
          <span>conference</span>
        </div>
      </div>
      <div className="meta-content">
        <div className="pxl-schedule">
          <div className="pxl-event--time">
            <i className="far fa-clock"></i> 9.00 - 9.30 PM
          </div>
          <div className="pxl-event--date">
            <i className="far fa-calendar-alt"></i> March 23, 2024
          </div>
        </div>
        <div className="pxl-inner">
          <h3 className="pxl-item--title style-color--1">
            <a href="https://demo.bravisthemes.com/festiva/event/event/">
              Challenges of a new Branding technique in Year 2024
            </a>
          </h3>
          <div className="pxl-content">
            <div className="pxl-item--author">
              <div className="img-author">
                <img
                  decoding="async"
                  src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/05/rayan-kellar.png"
                  width={99}
                  height={99}
                  alt="Rayan Kellar"
                  className="avatar avatar-100 wp-user-avatar wp-user-avatar-100 alignnone photo"
                />
              </div>
              <div className="info-author">
                <div className="name">
                  <a href="https://demo.bravisthemes.com/festiva/author/admin/" title="Posts by Rayan Kellar" rel="author">
                    Rayan Kellar
                  </a>
                </div>
                <div className="pxl-user--position">Author, Cleaner</div>
              </div>
            </div>
            <div className="pxl-item--summary">
              Assessing the effectiveness of new branding techniques can be challenging
            </div>
          </div>
        </div>
        <div className="pxl-item--button button">
          <a href="https://demo.bravisthemes.com/festiva/event/event/">Learn More</a>
        </div>
        {/* SVG Background Content */}
        <div className="pxl-bg--content">
          <svg className="svg" xmlns="http://www.w3.org/2000/svg" width="724" height="377" viewBox="0 0 724 377" fill="none">
            <path d="M152.439 82.2091L13 196.977L217.511 144.81L43.9866 360L592.448 17L418.924 320.875L704 133.072"
              stroke="url(#paint0_linear_5151_2483)" strokeWidth="40" strokeLinecap="round"
            ></path>
            <defs>
              <linearGradient id="paint0_linear_5151_2483" x1="13" y1="188.5" x2="704" y2="188.5" gradientUnits="userSpaceOnUse">
                <stop stopColor="#E100A8"></stop>
                <stop offset="1" stopColor="#71009C"></stop>
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      {/* Additional SVG background */}
      <div className="pxl-bg--holder">
        <svg width="339" height="343" viewBox="0 0 339 343" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* ... SVG PATHS OMITTED FOR BREVITY (copy content here if needed) ... */}
        </svg>
      </div>
    </div>
  </div>
);

export default EventCard2;
