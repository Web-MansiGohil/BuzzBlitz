// EventVenueSection.jsx


export default function EventVenueSection() {
  return (
    <section className="w-full relative bg-transparent py-16">
      <div className="absolute inset-0 pointer-events-none" />
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-12">
          {/* Left Column */}
          <div className="md:w-1/2 flex flex-col justify-center">
            <div className="mb-4">
              <span className="uppercase text-xs tracking-widest text-purple-600 font-bold">
                EVENT VENUE
              </span>
            </div>
            <h3 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
              Get the best experience<br />
              in the world of marketing
            </h3>
            <p className="text-gray-700 mb-6">
              Like previous year this year we are arranging world marketing summit 2024. Its the gathering of all the big.
            </p>
            {/* List 1 */}
            <div className="flex items-center gap-4 mb-4">
              <span className="flex-shrink-0 bg-purple-600 rounded-full p-2">
                {/* Calendar SVG */}
                <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37" fill="none">
                  <g>
                    <path d="M31.8653 35.338H5.13168C3.38573 35.338 1.96484 33.9171 1.96484 32.1706V7.67997C1.96484 5.93346 3.38573 4.51257 5.13168 4.51257H31.8653C33.6112 4.51257 35.0321 5.93346 35.0321 7.67997V32.1706C35.0321 33.9171 33.6112 35.338 31.8653 35.338ZM5.13168 6.19396C4.31284 6.19396 3.64623 6.86057 3.64623 7.67997V32.1706C3.64623 32.99 4.31284 33.6566 5.13168 33.6566H31.8653C32.6841 33.6566 33.3507 32.99 33.3507 32.1706V7.67997C33.3507 6.86057 32.6841 6.19396 31.8653 6.19396H5.13168Z" fill="white"></path>
                    <path d="M34.1914 12.9195H2.80554C2.34136 12.9195 1.96484 12.543 1.96484 12.0788C1.96484 11.6146 2.34136 11.2381 2.80554 11.2381H34.1914C34.6556 11.2381 35.0321 11.6146 35.0321 12.0788C35.0321 12.543 34.6556 12.9195 34.1914 12.9195Z" fill="white"></path>
                    <path d="M18.5008 8.43583C18.0367 8.43583 17.6602 8.05931 17.6602 7.59514V3.11144C17.6602 2.64727 18.0367 2.27075 18.5008 2.27075C18.965 2.27075 19.3415 2.64727 19.3415 3.11144V7.59514C19.3415 8.05931 18.965 8.43583 18.5008 8.43583Z" fill="white"></path>
                    <path d="M7.28991 8.43583C6.82574 8.43583 6.44922 8.05931 6.44922 7.59514V3.11144C6.44922 2.64727 6.82574 2.27075 7.28991 2.27075C7.75409 2.27075 8.1306 2.64727 8.1306 3.11144V7.59514C8.1306 8.05931 7.75409 8.43583 7.28991 8.43583Z" fill="white"></path>
                    <path d="M29.7079 8.43583C29.2437 8.43583 28.8672 8.05931 28.8672 7.59514V3.11144C28.8672 2.64727 29.2437 2.27075 29.7079 2.27075C30.1721 2.27075 30.5486 2.64727 30.5486 3.11144V7.59514C30.5486 8.05931 30.1721 8.43583 29.7079 8.43583Z" fill="white"></path>
                    <path d="M11.7736 21.8869H7.28991C6.82574 21.8869 6.44922 21.5104 6.44922 21.0462V16.5625C6.44922 16.0983 6.82574 15.7218 7.28991 15.7218H11.7736C12.2378 15.7218 12.6143 16.0983 12.6143 16.5625V21.0462C12.6143 21.5104 12.2378 21.8869 11.7736 21.8869ZM8.1306 20.2055H10.9329V17.4032H8.1306V20.2055Z" fill="white"></path>
                    <path d="M20.7404 21.8869H16.2567C15.7925 21.8869 15.416 21.5104 15.416 21.0462V16.5625C15.416 16.0983 15.7925 15.7218 16.2567 15.7218H20.7404C21.2046 15.7218 21.5811 16.0983 21.5811 16.5625V21.0462C21.5811 21.5104 21.2046 21.8869 20.7404 21.8869ZM17.0974 20.2055H19.8997V17.4032H17.0974V20.2055Z" fill="white"></path>
                    <path d="M29.7092 21.8869H25.2255C24.7613 21.8869 24.3848 21.5104 24.3848 21.0462V16.5625C24.3848 16.0983 24.7613 15.7218 25.2255 15.7218H29.7092C30.1733 15.7218 30.5498 16.0983 30.5498 16.5625V21.0462C30.5498 21.5104 30.1733 21.8869 29.7092 21.8869ZM26.0662 20.2055H28.8685V17.4032H26.0662V20.2055Z" fill="white"></path>
                    <path d="M11.7736 30.8543H7.28991C6.82574 30.8543 6.44922 30.4778 6.44922 30.0136V25.5299C6.44922 25.0657 6.82574 24.6892 7.28991 24.6892H11.7736C12.2378 24.6892 12.6143 25.0657 12.6143 25.5299V30.0136C12.6143 30.4778 12.2378 30.8543 11.7736 30.8543ZM8.1306 29.1729H10.9329V26.3706H8.1306V29.1729Z" fill="white"></path>
                    <path d="M20.7404 30.8543H16.2567C15.7925 30.8543 15.416 30.4778 15.416 30.0136V25.5299C15.416 25.0657 15.7925 24.6892 16.2567 24.6892H20.7404C21.2046 24.6892 21.5811 25.0657 21.5811 25.5299V30.0136C21.5811 30.4778 21.2046 30.8543 20.7404 30.8543ZM17.0974 29.1729H19.8997V26.3706H17.0974V29.1729Z" fill="white"></path>
                    <path d="M29.7092 30.8543H25.2255C24.7613 30.8543 24.3848 30.4778 24.3848 30.0136V25.5299C24.3848 25.0657 24.7613 24.6892 25.2255 24.6892H29.7092C30.1733 24.6892 30.5498 25.0657 30.5498 25.5299V30.0136C30.5498 30.4778 30.1733 30.8543 29.7092 30.8543ZM26.0662 29.1729H28.8685V26.3706H26.0662V29.1729Z" fill="white"></path>
                  </g>
                </svg>
              </span>
              <div>
                <div className="font-semibold text-gray-900">20-25 February, 2024</div>
                <div className="text-gray-500 text-sm">7.00 am - 8.00pm</div>
              </div>
            </div>
            {/* List 2 */}
            <div className="flex items-center gap-4">
              <span className="flex-shrink-0 bg-purple-600 rounded-full p-2">
                {/* Apartment SVG */}
                <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37" fill="none">
                  {/* ...SVG paths from your HTML... */}
                  {/* SVG omitted for brevity, copy full SVG from your HTML */}
                  <g>
                    <g>
                      <path d="M12.623 11.5685H14.7248" stroke="white" strokeWidth="2.32066" strokeMiterlimit="10"></path>
                      {/* ...copy the rest of your SVG paths here... */}
                    </g>
                  </g>
                </svg>
              </span>
              <div>
                <div className="font-semibold text-gray-900">Mine Arena Banquet Hall</div>
                <div className="text-gray-500 text-sm">23rd Avenue, Chicago USA</div>
              </div>
            </div>
          </div>
          {/* Right Column (Image) */}
          <div className="md:w-1/2 flex justify-center items-center">
            <img
              src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/home-1-image-1-1-550x785.png"
              alt="home-1-image-1"
              width={350}
              height={500}
              className="rounded-xl shadow-lg object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
