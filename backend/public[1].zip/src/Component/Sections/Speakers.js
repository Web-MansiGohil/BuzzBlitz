// components/SpeakersSection.jsx
import React from 'react';
import SVGDecorations from './SvgDecoration';
import SocialLinks from './SocialLink';

const speakers = [
  {
    name: 'Zayden Williams',
    position: 'CEO, Mindstation',
    image: 'https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/about-us-author-1.jpg',
    link: 'https://demo.bravisthemes.com/festiva/speaker-details/',
  },
  {
    name: 'Mark Antony',
    position: 'CEO, Mindstation',
    image: 'https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/about-us-author-6.jpg',
    link: 'https://demo.bravisthemes.com/festiva/speaker-details/',
  },
  {
    name: 'Jonathon Miller',
    position: 'CEO, Mindstation',
    image: 'https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/about-us-author-4.jpg',
    link: 'https://demo.bravisthemes.com/festiva/speaker-details/',
  },
  {
    name: 'Jimmy Heathway',
    position: 'CEO, Mindstation',
    image: 'https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/author-3.jpg',
    link: 'https://demo.bravisthemes.com/festiva/speaker-details/',
  },
  {
    name: 'Tyson Gardner',
    position: 'CEO, Mindstation',
    image: 'https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/about-us-author-2.jpg',
    link: 'https://demo.bravisthemes.com/festiva/speaker-details/',
  },
  {
    name: 'Mellissa Brayan',
    position: 'CEO, Mindstation',
    image: 'https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/05/our-speaker-author-9.jpg',
    link: 'https://demo.bravisthemes.com/festiva/speaker-details/',
  },
];

const SpeakersSection = () => {
  return (
    <section className="relative w-full py-16 bg-white overflow-visible">
      {/* Decorative vertical lines (like .pxl-section-line1 etc.) */}
      <div className="absolute inset-y-0 left-1/2 w-full max-w-7xl -translate-x-1/2 pointer-events-none z-0 hidden lg:block">
        <div className="h-full flex justify-between px-8">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="w-px bg-gray-200 opacity-40" />
          ))}
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <img
            src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-light.png"
            alt="Logo"
            className="h-16"
          />
        </div>

        {/* Heading */}
        <h2 className="text-center text-3xl md:text-4xl font-semibold text-gray-800 leading-snug mb-12">
          Our Amazing &amp; learned <br /> event Speakers
        </h2>

        {/* Grid */}
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {speakers.map((speaker, index) => (
            <div key={index} className="group relative text-center">
              <div className="relative overflow-hidden rounded-lg shadow-lg">
                <a href={speaker.link}>
                  <img
                    src={speaker.image}
                    alt={speaker.name}
                    className="w-full h-auto object-cover transition-transform duration-300 transform group-hover:scale-105"
                  />
                </a>

                {/* Decorative SVGs */}
                <div className="absolute inset-0 pointer-events-none">
                  <SVGDecorations />
                </div>
              </div>

              <div className="mt-4">
                <h5 className="text-lg font-semibold text-gray-900">
                  <a href={speaker.link}>{speaker.name}</a>
                </h5>
                <p className="text-sm text-gray-500">{speaker.position}</p>
                <SocialLinks />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};



export default SpeakersSection;
