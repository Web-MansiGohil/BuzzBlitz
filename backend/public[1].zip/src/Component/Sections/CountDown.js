import React, { useEffect, useState } from 'react';

const CountdownSection = () => {
  const [timeLeft, setTimeLeft] = useState(getTimeRemaining());

  function getTimeRemaining() {
    const eventDate = new Date();
    eventDate.setDate(eventDate.getDate() + 439); // 439 days from now

    const total = Date.parse(eventDate) - Date.parse(new Date());
    const seconds = Math.floor((total / 1000) % 60);
    const minutes = Math.floor((total / 1000 / 60) % 60);
    const hours = Math.floor((total / (1000 * 60 * 60)) % 24);
    const days = Math.floor(total / (1000 * 60 * 60 * 24));

    return {
      total,
      days,
      hours,
      minutes,
      seconds
    };
  }

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(getTimeRemaining());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatNumbers = (num) => {
    return num.toString().padStart(2, '0').split('');
  };

  return (
    <section className="w-full bg-white px-4 py-12">
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between">
        
        {/* Left Column */}
        <div className="w-full md:w-1/2 mb-8 md:mb-0">
          <h3 className="text-xl font-bold text-gray-800 mb-4">COUNTDOWN</h3>

          <img
            src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-1-light.png"
            alt="Logo"
            width="218"
            height="80"
            className="hidden md:block mb-6"
          />

          <h3 className="text-2xl font-semibold text-gray-900 animate-fade-in-up">Countdown Until the Event. Register Now</h3>
        </div>

        {/* Right Column: Countdown */}
        <div className="w-full md:w-1/2 flex justify-center">
          <div className="grid grid-cols-4 gap-4 text-center text-gray-800">
            {/* Days */}
            <div>
              <div className="flex justify-center space-x-1 text-4xl font-bold">
                {formatNumbers(timeLeft.days).map((num, idx) => (
                  <span key={idx}>{num}</span>
                ))}
              </div>
              <div className="text-sm mt-1">Days</div>
            </div>

            {/* Hours */}
            <div>
              <div className="flex justify-center space-x-1 text-4xl font-bold">
                {formatNumbers(timeLeft.hours).map((num, idx) => (
                  <span key={idx}>{num}</span>
                ))}
              </div>
              <div className="text-sm mt-1">Hours</div>
            </div>

            {/* Minutes */}
            <div>
              <div className="flex justify-center space-x-1 text-4xl font-bold">
                {formatNumbers(timeLeft.minutes).map((num, idx) => (
                  <span key={idx}>{num}</span>
                ))}
              </div>
              <div className="text-sm mt-1">Minutes</div>
            </div>

            {/* Seconds */}
            <div>
              <div className="flex justify-center space-x-1 text-4xl font-bold">
                {formatNumbers(timeLeft.seconds).map((num, idx) => (
                  <span key={idx}>{num}</span>
                ))}
              </div>
              <div className="text-sm mt-1">Seconds</div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default CountdownSection;
