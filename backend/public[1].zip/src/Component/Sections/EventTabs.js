import { Tabs, TabsList, TabsTrigger, TabsContent } from "../../Components/ui/tabs";

const days = [
  { value: "day1", label: "DAY 1", date: "Feb 22,2024" },
  { value: "day2", label: "DAY 2", date: "Feb 23,2024" },
  { value: "day3", label: "DAY 3", date: "Feb 24,2024" },
  { value: "day4", label: "DAY 4", date: "Feb 25,2024" },
  { value: "day5", label: "DAY 5", date: "Feb 26,2024" },
];

export default function EventDaysTabs() {
  return (
    <div className="wrap-title">
      <Tabs defaultValue="day1" className="w-full">
        <TabsList className="flex flex-wrap gap-2 bg-muted p-2 rounded-lg">
          {days.map((tab) => (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              className="flex flex-col items-center px-6 py-2 text-base font-semibold data-[state=active]:bg-primary data-[state=active]:text-white rounded-lg transition-colors"
            >
              <span>{tab.label}</span>
              <span className="pxl-sub--title text-xs font-normal text-muted-foreground">
                {tab.date}
              </span>
            </TabsTrigger>
          ))}
        </TabsList>
        {days.map((tab) => (
          <TabsContent key={tab.value} value={tab.value} className="mt-6">
            <div className="p-6 border rounded-lg bg-background shadow-sm">
              <h2 className="text-xl font-bold mb-2">{tab.label}</h2>
              <div className="text-muted-foreground">{tab.date}</div>
              {/* Place your content for each day here */}
              <p className="mt-4 text-gray-600">Content for {tab.label} goes here.</p>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
