import Button from "../../Components/ui/button"
import { Card ,CardContent,CardFooter } from "../../Components/ui/card"

export default function EventCard() {
  return (
    <Card className="relative max-w-xl mx-auto overflow-hidden shadow-lg">
      <div className="relative">
        <a href="https://demo.bravisthemes.com/festiva/event/event-details-2/">
          <img
            src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/06/home-tab-event-4-441x374.webp"
            alt="home-tab-event-4"
            className="w-full h-64 object-cover"
          />
        </a>
        <div className="absolute top-4 left-4 bg-pink-600 text-white text-xs px-2 py-1 rounded">
          conference
        </div>
      </div>
      <CardContent className="p-6">
        <div className="flex items-center text-sm text-gray-500 gap-4 mb-2">
          <span className="flex items-center gap-1">
            <i className="far fa-clock" /> 9.00 - 9.30 PM
          </span>
          <span className="flex items-center gap-1">
            <i className="far fa-calendar-alt" /> March 23, 2024
          </span>
        </div>
        <h3 className="text-lg font-bold mb-2">
          <a
            href="https://demo.bravisthemes.com/festiva/event/event-details-2/"
            className="hover:underline"
          >
            Challenges of a new Branding technique in Year 2024
          </a>
        </h3>
        <div className="flex items-center gap-3 mb-2">
          <img
            src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/05/rayan-kellar.png"
            alt="Rayan Kellar"
            className="w-10 h-10 rounded-full"
          />
          <div>
            <div className="font-medium">
              <a
                href="https://demo.bravisthemes.com/festiva/author/admin/"
                className="hover:underline"
              >
                Rayan Kellar
              </a>
            </div>
            <div className="text-xs text-gray-500">Author, Cleaner</div>
          </div>
        </div>
        <p className="text-gray-700 mb-4">
          Assessing the effectiveness of new branding techniques can be challenging
        </p>
      </CardContent>
      <CardFooter className="flex justify-between items-center p-6 pt-0">
        <Button asChild>
          <a href="https://demo.bravisthemes.com/festiva/event/event-details-2/">
            Learn More
          </a>
        </Button>
        {/* SVG Background */}
        <span className="absolute right-0 bottom-0 opacity-20 pointer-events-none">
          <MyGradientSVG />
        </span>
      </CardFooter>
    </Card>
  )
}

// SVG with gradients as a separate component
function MyGradientSVG() {
  return (
    <svg width="120" height="60" viewBox="0 0 724 377" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="paint12_linear_5151_2486" x1="395.287" y1="103.277" x2="80.9786" y2="103.277" gradientUnits="userSpaceOnUse">
          <stop stopColor="#E91A83" />
          <stop offset="1" stopColor="#4C24C1" />
        </linearGradient>
        {/* ...add more gradients if needed */}
      </defs>
      <path
        d="M152.439 82.2091L13 196.977L217.511 144.81L43.9866 360L592.448 17L418.924 320.875L704 133.072"
        stroke="url(#paint12_linear_5151_2486)"
        strokeWidth="40"
        strokeLinecap="round"
      />
    </svg>
  )
}
