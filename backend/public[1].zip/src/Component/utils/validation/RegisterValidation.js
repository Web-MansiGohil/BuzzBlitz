const  validate= (values) => {
    const errors = {};

    if (!values.name?.trim()) {
        errors.name = "First  Name Is Required";
    } else if (!/^[a-zA-Z ]{3,50}$/.test(values.name)) {
        errors.name = 'Name must be 3-50 characters and contain only letters';
    }

    if (!values.lastname?.trim()) {
        errors.lastname = "Last  Name Is Required";
    } else if (!/^[a-zA-Z ]{3,50}$/.test(values.lastname)) {
        errors.lastname = 'Name must be 3-50 characters and contain only letters';
    }

    if (!values.email) {
        errors.email = "Email Is Required";
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
        errors.email = "Email Is Not Valid";
    }

    if (!values.phone) {
        errors.phone = "Phone Is Required";
    } else if (!/^\d{10}$/.test(values.phone)) {
        errors.phone = "Phone Number Is Not Valid";
    }

 if (!values.password?.trim()) {
    errors.password = "Password Is Required";
} else if (values.password.length < 6) {
    errors.password = "Password Must Be at least 6 Characters";
}

if (!values.confirmpassword?.trim()) {
    errors.confirmpassword = "Confirm Password Is Required";
} else if (values.confirmpassword !== values.password) {
    errors.confirmpassword = "Confirm Password Does Not Match";
}


    return errors;
}
export default validate;