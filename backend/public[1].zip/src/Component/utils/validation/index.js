import ValidateRegister from './RegisterValidation';
import ValidateLogin from './LoginValidation';

export {
    ValidateRegister,
    ValidateLogin,
}