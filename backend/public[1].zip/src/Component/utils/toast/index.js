import { toast } from 'react-toastify';

const Toast = (type, message) => {
  if (type === 'success') {
    toast.success(message, {
      position: 'top-right',
      autoClose: 5000,
      hideProgressBar: false,
    });
  } else if (type === 'error') {
    toast.error(message, {
      position: 'top-right',
      autoClose: 5000,
      hideProgressBar: false,
    });
  }
};

export default Toast;
