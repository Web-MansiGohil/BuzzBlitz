const  TOKEN_KEY ='userAccess';

const getToken =()=>{
    if (typeof window !== 'undefined'){
        const token =localStorage.getItem(TOKEN_KEY);
        if(!token){
            return false;
        }
        return token;
    }
}

export {getToken};
