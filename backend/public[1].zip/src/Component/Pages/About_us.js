import React from 'react'

const About_us = () => {
  return (
    <div>About_us</div>
  )
}

export default About_us