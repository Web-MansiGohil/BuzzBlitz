import CountdownSection from "./CountDown"
import EventDaysTabs from "./EventTabs"
import EventVenueSection from "./EventVenue"
import ExploreUsSection from "./ExploreUs"
import MarketingSummitFullSection from "./Maincomp"
import PartnerCarousel from "./PartnerCarousel"
import SpeakersSection from "./Speakers"
import VideoSection from "./VideoSection"


const Home = () => {
    return (
        <>
            <MarketingSummitFullSection />
            <ExploreUsSection />
            <EventVenueSection />
            <EventDaysTabs />
            <CountdownSection />
            {/* <EventCard2/> */}
            <VideoSection />
            <SpeakersSection />
            <PartnerCarousel />
        </>
    )
}

export default Home