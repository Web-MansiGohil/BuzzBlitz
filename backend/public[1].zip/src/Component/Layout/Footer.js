// src/components/Footer.tsx

import { FaFacebookF, FaTwitter, FaInstagram, FaPinterestP, FaYoutube } from "react-icons/fa";
import Button from "../../Components/ui/button";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-10 px-4">
      <div className="container mx-auto flex flex-col items-center gap-8">
        {/* Logo */}
        <a href="https://demo.bravisthemes.com/festiva/home/" className="mb-4">
          <img
            src="https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/04/logo-footer.png"
            alt="Festiva Logo"
            width={103}
            height={103}
            className="mx-auto"
          />
        </a>

        {/* Heading */}
        <h3 className="text-2xl font-bold text-center">
          <span className="block">Join the biggest Marketing</span>
          <span className="block">Community of the world</span>
        </h3>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Button variant="default" asChild>
            <a href="#">Be a partner</a>
          </Button>
          <Button variant="secondary" asChild>
            <a href="https://demo.bravisthemes.com/festiva/get-ticket/">Purchase Ticket</a>
          </Button>
        </div>

        {/* Navigation Links */}
        <ul className="flex flex-wrap justify-center gap-6 mt-6 text-sm">
          <li>
            <a href="https://demo.bravisthemes.com/festiva/event-schedule/" className="hover:underline">
              Schedule
            </a>
          </li>
          <li>
            <a href="https://demo.bravisthemes.com/festiva/speaker-1/" className="hover:underline">
              About Speakers
            </a>
          </li>
          <li>
            <a href="https://demo.bravisthemes.com/festiva/pricing-table/" className="hover:underline">
              Booking Info
            </a>
          </li>
          <li>
            <a href="#" className="hover:underline">
              Terms &amp; Conditions
            </a>
          </li>
          <li>
            <a href="#" className="hover:underline">
              Privacy Policy
            </a>
          </li>
        </ul>

        {/* Social Links */}
        <div className="flex gap-4 mt-4">
          <a href="#" aria-label="Facebook" className="hover:text-blue-500">
            <FaFacebookF size={20} />
          </a>
          <a href="#" aria-label="Twitter" className="hover:text-blue-400">
            <FaTwitter size={20} />
          </a>
          <a href="#" aria-label="Instagram" className="hover:text-pink-500">
            <FaInstagram size={20} />
          </a>
          <a href="#" aria-label="Pinterest" className="hover:text-red-500">
            <FaPinterestP size={20} />
          </a>
          <a href="#" aria-label="YouTube" className="hover:text-red-600">
            <FaYoutube size={20} />
          </a>
        </div>

        {/* Copyright */}
        <div className="mt-6 text-xs text-gray-400 text-center">
          &copy; {new Date().getFullYear()} Festiva. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
