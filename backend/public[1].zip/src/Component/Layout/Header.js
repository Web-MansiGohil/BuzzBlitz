// File: Header.jsx

import React, { useState } from "react";
import Button from "../../Components/ui/button";
import logoUrl from "../../../src/fevicon.jpeg";


const showcaseItems = [
  {
    href: "https://demo.bravisthemes.com/festiva/",
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/01_Festiva_conference_index-1.jpg",
    title: "Home 1",
    onePage: "https://demo.bravisthemes.com/festiva/home-1-one-page",
  },
  {
    href: "https://demo.bravisthemes.com/festiva/home-2/",
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/02_Festiva_conference_index-6.jpg",
    title: "Home 2",
    onePage: "https://demo.bravisthemes.com/festiva/home-2-one-page",
  },
  {
    href: "https://demo.bravisthemes.com/festiva/home-3/",
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/03_index-3_Home-3.jpg",
    title: "Home 3",
    onePage: "https://demo.bravisthemes.com/festiva/home-3-one-page",
  },
  {
    href: "https://demo.bravisthemes.com/festiva/home-4/",
    img: "https://demo.bravisthemes.com/festiva/wp-content/uploads/2024/08/04_Festiva_conference_index-4.jpg",
    title: "Home 4",
    onePage: "https://demo.bravisthemes.com/festiva/home-4-one-page",
  },
];

const navLinks = [
  {
    label: "Home",
    href: "/home",
    // megaMenu: true
  },
  {
    label: "About Us",
    href: "/about_us",
  },
  {
    label: "Event",
    subMenu: [
      {
        label: "Event Schedule",
        href: "https://demo.bravisthemes.com/festiva/event-schedule/",
      },
      {
        label: "Event Details",
        subMenu: [
          {
            label: "Event Details 1",
            href: "https://demo.bravisthemes.com/festiva/event/event-details-2/",
          },
          {
            label: "Event Details 2",
            href: "https://demo.bravisthemes.com/festiva/event/event/",
          },
        ],
      },
    ],
  },
  {
    label: "Pages",
    subMenu: [
      {
        label: "Speaker",
        subMenu: [
          {
            label: "Our Speaker 1",
            href: "https://demo.bravisthemes.com/festiva/speaker-1/",
          },
          {
            label: "Our Speaker 2",
            href: "https://demo.bravisthemes.com/festiva/speaker-2/",
          },
          {
            label: "Speaker Details",
            href: "https://demo.bravisthemes.com/festiva/speaker-details/",
          },
        ],
      },
      // {
      //   label: "Image Gallery",
      //   href: "https://demo.bravisthemes.com/festiva/event-image-gallery/",
      // },
      // {
      //   label: "Get Ticket",
      //   href: "https://demo.bravisthemes.com/festiva/get-ticket/",
      // },
      {
        label: "Pricing Table",
        href: "https://demo.bravisthemes.com/festiva/pricing-table/",
      },
      {
        label: "Registration",
        href: "/register",
      },
      {
        label: "Venus Info",
        href: "/venus-info",
      },
      {
        label: "404 Error",
        href: "https://demo.bravisthemes.com/festiva/404-error",
      },
    ],
  },
  {
    label: "Blog",
    href: "/blog",
    // subMenu: [
    //   {
    //     label: "Blog Standard",
    //     href: "https://demo.bravisthemes.com/festiva/blog-standard/",
    //     subMenu: [
    //       {
    //         label: "Left Sidebar",
    //         href:
    //           "https://demo.bravisthemes.com/festiva/blog-standard/?sidebar-blog=left",
    //       },
    //       {
    //         label: "Right Sidebar",
    //         href:
    //           "https://demo.bravisthemes.com/festiva/blog-standard/?sidebar-blog=right",
    //       },
    //       {
    //         label: "No Sidebar",
    //         href:
    //           "https://demo.bravisthemes.com/festiva/blog-standard/?sidebar-blog=0",
    //       },
    //     ],
    //   },
    //   {
    //     label: "Blog Grid",
    //     href: "https://demo.bravisthemes.com/festiva/blog-grid/",
    //   },
    //   {
    //     label: "Blog Details",
    //     href: "https://demo.bravisthemes.com/festiva/blog-details/",
    //     subMenu: [
    //       {
    //         label: "Left Sidebar",
    //         href:
    //           "https://demo.bravisthemes.com/festiva/blog-details/?sidebar-blog=left",
    //       },
    //       {
    //         label: "Right Sidebar",
    //         href:
    //           "https://demo.bravisthemes.com/festiva/blog-details/?sidebar-blog=right",
    //       },
    //       {
    //         label: "No Sidebar",
    //         href:
    //           "https://demo.bravisthemes.com/festiva/blog-details/?sidebar-blog=0",
    //       },
    //     ],
    //   },
    // ],
  },
  {
    label: "Contact Us",
    href: "/contact_us",
  },
];

// Recursive Dropdown Menu
const DropdownMenu = ({ items}) => {
  const [openIndex, setOpenIndex] = useState(null);

  return (
    <ul className="bg-white shadow-lg rounded min-w-[200px] py-2">
      {items.map((item, idx) => (
        <li
          key={item.label}
          className="relative group"
          onMouseEnter={() => setOpenIndex(idx)}
          onMouseLeave={() => setOpenIndex(null)}
        >
          {item.href ? (
            <a
              href={item.href}
              className="block px-4 py-2 hover:bg-gray-100 text-gray-800 whitespace-nowrap"
            >
              {item.label}
            </a>
          ) : (
            <span className="block px-4 py-2 text-gray-800 cursor-default">
              {item.label}
            </span>
          )}
          {item.subMenu && openIndex === idx && (
            <div className="absolute left-full top-0 z-50">
              <DropdownMenu items={item.subMenu} />
            </div>
          )}
        </li>
      ))}
    </ul>
  );
};

// Mega Menu for Home
const MegaMenu = () => (
  <div className="absolute left-0 top-full w-[900px] bg-white shadow-xl rounded p-6 z-50">
    <div className="flex gap-4">
      {showcaseItems.map((item) => (
        <div key={item.title} className="w-1/4">
          <div className="relative group">
            <img
              src={item.img}
              alt={item.title}
              className="rounded-lg shadow mb-2"
            />
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-60 opacity-0 group-hover:opacity-100 transition-opacity gap-2 rounded-lg">
              <Button asChild variant="default" className="w-28">
                <a href={item.href}>View Demo</a>
              </Button>
              <Button asChild variant="outline" className="w-28">
                <a href={item.onePage}>One Page</a>
              </Button>
            </div>
          </div>
          <h5 className="text-center mt-2 font-semibold">
            <a
              href={item.href}
              className="hover:underline text-gray-900"
            >
              {item.title}
            </a>
          </h5>
        </div>
      ))}
    </div>
  </div>
);

const Header = () => {
  const [openMenu, setOpenMenu] = useState(null);

  return (
    <header className="sticky top-0 z-50 bg-gradient-to-r from-purple-600 to-pink-500 shadow">
      <div className="container mx-auto flex items-center justify-between py-4 px-6">
        {/* Logo */}
        <a href="/home" className="flex items-center">
          <img src={logoUrl} alt="Festiva Logo" className="h-12 w-auto" />
          <h1 className="text-white text-[24px]">EventHub</h1>
        </a>

        {/* Navigation */}
        <nav>
          <ul className="flex items-center gap-2">
            {navLinks.map((link, idx) => (
              <li
                key={link.label}
                className="relative"
                onMouseEnter={() => setOpenMenu(idx)}
                onMouseLeave={() => setOpenMenu(null)}
              >
                <a
                  href={link.href || "#"}
                  className="px-4 py-2 text-white font-medium hover:text-yellow-300 transition"
                >
                  {link.label}
                  {(link.subMenu || link.megaMenu) && (
                    <span className="ml-1 text-xs">▼</span>
                  )}
                </a>
                {/* Mega Menu for Home */}
                {link.megaMenu && openMenu === idx && <MegaMenu />}
                {/* Dropdown for others */}
                {link.subMenu && openMenu === idx && (
                  <div className="absolute left-0 top-full mt-2 z-50">
                    <DropdownMenu items={link.subMenu} />
                  </div>
                )}
              </li>
            ))}
          </ul>
        </nav>
        {/* Hidden Panel Button */}
        <div className="ml-4 flex md:hidden">
          {/* You can replace this with a shadcn/ui Drawer or Dialog for mobile */}
          <Button variant="outline" size="icon">
            <span className="sr-only">Open menu</span>
            <svg
              className="w-6 h-6 text-white"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
