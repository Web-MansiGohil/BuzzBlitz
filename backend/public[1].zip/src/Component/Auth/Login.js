// LoginForm.jsx
export default function LoginForm() {
  return (
    <form className="max-w-sm mx-auto p-4 bg-white rounded shadow">
      <div className="mb-4">
        <label className="block text-gray-700 mb-2">Email</label>
        <input
          type="email"
          className="border border-gray-300 p-2 rounded w-full focus:outline-none focus:ring focus:border-blue-400"
          placeholder="you@domain.com"
        />
      </div>
      <div className="mb-4">
        <label className="block text-gray-700 mb-2">Password</label>
        <input
          type="password"
          className="border border-gray-300 p-2 rounded w-full focus:outline-none focus:ring focus:border-blue-400"
        />
      </div>
      <button
        type="submit"
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 w-full"
      >
        Login
      </button>
    </form>
  );
}
