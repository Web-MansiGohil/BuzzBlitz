import React, { useState } from "react";

const colleges = [
    "SVNIT Surat",
    "LDRP Institute of Technology & Research",
    "Silver Oak College of Engineering & Technology",
    "Uka Tarsadia University",
    "SCET Surat",
    "GEC Surat",
];

const itEvents = [
    "Coding Contest",
    "Hackathon",
    "Tech Talk",
];

const itGames = [
    "CS:GO",
    "Valorant",
    "FIFA",
];

const nonItGames = [
    "Football",
    "Basketball",
    "Badminton",
];

const years = ["FY", "SY", "TY"];

const RegistrationForm = () => {
    const [formData, setFormData] = useState({
        studentName: "",
        year: "",
        college: "",
        event: "",
        eventType: "",
        itGame: "",
        nonItGame: "",
        course: "",
        email: "",
        mobile: "",
        teamMembers: 1,
    });

    const [errors, setErrors] = useState({});

    const validate = () => {
        const errs = {};
        if (!formData.studentName.trim()) errs.studentName = "Student name is required";
        if (!formData.year) errs.year = "Year is required";
        if (!formData.college) errs.college = "College is required";
        if (!formData.event) errs.event = "Event is required";
        if (!formData.eventType) errs.eventType = "Event type is required";
        if (formData.eventType === "IT Games" && !formData.itGame)
            errs.itGame = "Please select an IT game";
        if (formData.eventType === "Non IT Games" && !formData.nonItGame)
            errs.nonItGame = "Please select a Non IT game";
        if (!formData.course.trim()) errs.course = "Course is required";

        if (!formData.email) {
            errs.email = "Email is required";
        } else {
            // Simple email regex
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(formData.email)) errs.email = "Email is invalid";
        }

        if (!formData.mobile) {
            errs.mobile = "Mobile number is required";
        } else {
            const mobileRegex = /^[6-9]\d{9}$/; // Indian 10-digit mobile starting with 6-9
            if (!mobileRegex.test(formData.mobile)) errs.mobile = "Mobile number is invalid";
        }

        if (!formData.teamMembers || formData.teamMembers < 1)
            errs.teamMembers = "At least 1 team member required";

        setErrors(errs);

        return Object.keys(errs).length === 0;
    };

    const handleChange = (e) => {
        const { name, value } = e.target;

        // If eventType changes, reset itGame and nonItGame values
        if (name === "eventType") {
            setFormData((prev) => ({
                ...prev,
                [name]: value,
                itGame: "",
                nonItGame: "",
            }));
        } else {
            setFormData((prev) => ({
                ...prev,
                [name]: value,
            }));
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (validate()) {
            alert("Registration Successful!");
            console.log(formData);
            // Reset form or you can send data to backend here
            setFormData({
                studentName: "",
                year: "",
                college: "",
                event: "",
                eventType: "",
                itGame: "",
                nonItGame: "",
                course: "",
                email: "",
                mobile: "",
                teamMembers: 1,
            });
            setErrors({});
        }
    };

    return (
        <div className="max-w-3xl mx-auto mt-10 p-6 bg-white shadow rounded-md">
            <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
                Student Registration Form
            </h2>
            <form onSubmit={handleSubmit} noValidate>
                {/* Student Name */}
                <div className="mb-4">
                    <label htmlFor="studentName" className="block text-gray-700 font-medium mb-1">
                        Student Name <span className="text-red-500">*</span>
                    </label>
                    <input
                        id="studentName"
                        type="text"
                        name="studentName"
                        value={formData.studentName}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.studentName ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                    />
                    {errors.studentName && (
                        <p className="text-red-500 text-sm mt-1">{errors.studentName}</p>
                    )}
                </div>

                {/* Year Dropdown */}
                <div className="mb-4">
                    <label htmlFor="year" className="block text-gray-700 font-medium mb-1">
                        Year <span className="text-red-500">*</span>
                    </label>
                    <select
                        id="year"
                        name="year"
                        value={formData.year}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.year ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                    >
                        <option value="">Select Year</option>
                        {years.map((yr) => (
                            <option key={yr} value={yr}>
                                {yr}
                            </option>
                        ))}
                    </select>
                    {errors.year && <p className="text-red-500 text-sm mt-1">{errors.year}</p>}
                </div>

                {/* College Dropdown */}
                <div className="mb-4">
                    <label htmlFor="college" className="block text-gray-700 font-medium mb-1">
                        College Name <span className="text-red-500">*</span>
                    </label>
                    <select
                        id="college"
                        name="college"
                        value={formData.college}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.college ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                    >
                        <option value="">Select College</option>
                        {colleges.map((clg) => (
                            <option key={clg} value={clg}>
                                {clg}
                            </option>
                        ))}
                    </select>
                    {errors.college && <p className="text-red-500 text-sm mt-1">{errors.college}</p>}
                </div>

                {/* Event Dropdown */}
                <div className="mb-4">
                    <label htmlFor="event" className="block text-gray-700 font-medium mb-1">
                        IT Event <span className="text-red-500">*</span>
                    </label>
                    <select
                        id="event"
                        name="event"
                        value={formData.event}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.event ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                    >
                        <option value="">Select IT Event</option>
                        {itEvents.map((itEvt) => (
                            <option key={itEvt} value={itEvt}>
                                {itEvt}
                            </option>
                        ))}
                    </select>
                    {errors.event && <p className="text-red-500 text-sm mt-1">{errors.event}</p>}
                </div>

                {/* Event Type (IT Games / Non IT Games) */}
                <div className="mb-4">
                    <label className="block text-gray-700 font-medium mb-1">
                        Select Event Type <span className="text-red-500">*</span>
                    </label>
                    <select
                        name="eventType"
                        value={formData.eventType}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.eventType ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                    >
                        <option value="">-- Select Event Type --</option>
                        <option value="IT Games">IT Games</option>
                        <option value="Non IT Games">Non IT Games</option>
                    </select>
                    {errors.eventType && <p className="text-red-500 text-sm mt-1">{errors.eventType}</p>}
                </div>

                {/* Conditional Dropdown for IT Games */}
                {formData.eventType === "IT Games" && (
                    <div className="mb-4">
                        <label htmlFor="itGame" className="block text-gray-700 font-medium mb-1">
                            Select IT Game <span className="text-red-500">*</span>
                        </label>
                        <select
                            id="itGame"
                            name="itGame"
                            value={formData.itGame}
                            onChange={handleChange}
                            className={`w-full px-3 py-2 border ${errors.itGame ? "border-red-500" : "border-gray-300"
                                } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                        >
                            <option value="">Select IT Game</option>
                            {itGames.map((game) => (
                                <option key={game} value={game}>
                                    {game}
                                </option>
                            ))}
                        </select>
                        {errors.itGame && <p className="text-red-500 text-sm mt-1">{errors.itGame}</p>}
                    </div>
                )}

                {/* Conditional Dropdown for Non IT Games */}
                {formData.eventType === "Non IT Games" && (
                    <div className="mb-4">
                        <label htmlFor="nonItGame" className="block text-gray-700 font-medium mb-1">
                            Select Non IT Game <span className="text-red-500">*</span>
                        </label>
                        <select
                            id="nonItGame"
                            name="nonItGame"
                            value={formData.nonItGame}
                            onChange={handleChange}
                            className={`w-full px-3 py-2 border ${errors.nonItGame ? "border-red-500" : "border-gray-300"
                                } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                        >
                            <option value="">Select Non IT Game</option>
                            {nonItGames.map((game) => (
                                <option key={game} value={game}>
                                    {game}
                                </option>
                            ))}
                        </select>
                        {errors.nonItGame && <p className="text-red-500 text-sm mt-1">{errors.nonItGame}</p>}
                    </div>
                )}

                {/* Course */}
                <div className="mb-4">
                    <label htmlFor="course" className="block text-gray-700 font-medium mb-1">
                        Course <span className="text-red-500">*</span>
                    </label>
                    <input
                        id="course"
                        type="text"
                        name="course"
                        value={formData.course}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.course ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                    />
                    {errors.course && <p className="text-red-500 text-sm mt-1">{errors.course}</p>}
                </div>

                {/* Email */}
                <div className="mb-4">
                    <label htmlFor="email" className="block text-gray-700 font-medium mb-1">
                        Email ID <span className="text-red-500">*</span>
                    </label>
                    <input
                        id="email"
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.email ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                    />
                    {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                </div>

                {/* Mobile Number */}
                <div className="mb-4">
                    <label htmlFor="mobile" className="block text-gray-700 font-medium mb-1">
                        Mobile Number <span className="text-red-500">*</span>
                    </label>
                    <input
                        id="mobile"
                        type="tel"
                        name="mobile"
                        maxLength="10"
                        value={formData.mobile}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.mobile ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                        placeholder="10 digit mobile number"
                    />
                    {errors.mobile && <p className="text-red-500 text-sm mt-1">{errors.mobile}</p>}
                </div>

                {/* Team Members */}
                <div className="mb-6">
                    <label htmlFor="teamMembers" className="block text-gray-700 font-medium mb-1">
                        Team Members <span className="text-red-500">*</span>
                    </label>
                    <input
                        id="teamMembers"
                        type="number"
                        min="1"
                        name="teamMembers"
                        value={formData.teamMembers}
                        onChange={handleChange}
                        className={`w-full px-3 py-2 border ${errors.teamMembers ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400`}
                    />
                    {errors.teamMembers && (
                        <p className="text-red-500 text-sm mt-1">{errors.teamMembers}</p>
                    )}
                </div>

                <button
                    type="submit"
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md transition"
                >
                    Register
                </button>
            </form>
        </div>
    );
};

export default RegistrationForm;
