import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { authService } from "../../service/auth";
import axios from 'axios';


const initialState = {
  msg: "",
  user: null,
  token: "",
  loading: false,
  error: false,
  isLoggedIn: false,
}

export const registerInUser = createAsyncThunk("register", async (payload) => {
  const { data, status } = await authService.Register(payload);
  data.status = status;
  return data;
})

export const logInUser =createAsyncThunk("login",async (payload)=>{
  const {data,status}=await authService.Login(payload);
  data.status=status;
  return data;
})

const AuthSlice = createSlice({
  name: "authUser",
  initialState,
  reducers: {
    logoutAuth: (state) => {
      state.token = null;
      localStorage.clear();
      state.msg = "";
      state.user = null;
      state.loading = false;
      state.error = null;
      state.isLoggedIn = false;
    },
    setSingleUser: (state, { payload }) => {
      state.user = payload;
      state.isLoggedIn = true;
    },
    checkLoggedIn: (state, { payload }) => {
      state.isLoggedIn = payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(registerInUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(registerInUser.fulfilled, (state, { payload }) => {
        console.log(payload)  
        state.loading = false;
        if (payload.success) {
          state.user = payload.data;
          state.token = payload.data.token;
          state.isLoggedIn = true;
          localStorage.setItem("userAccess", `Bearer ${payload.data.token}`);
        } else {
          state.error = payload.msg || "Login failed";
        }
      })
      .addCase(registerInUser.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload || "An error occurred";
      });
  }
});

export const { logoutAuth, checkLoggedIn,setSingleUser  } = AuthSlice.actions;
export default AuthSlice.reducer;
