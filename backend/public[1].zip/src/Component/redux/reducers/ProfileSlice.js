import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { profileService } from "../../service/profile";
import axios from 'axios';


const initialState ={
    profile:[],
    loading:false,
    error:"",
};

export const profile =createAsyncThunk("profile",async (payload)=>{
    const {data,status}=await profileService.Profile(payload);
    data.status=status;
    return data;
})

const ProfileSlice = createSlice({
  name: "profileUser",
  initialState,
  reducers: {
    logoutProfile: (state) => {
      state.token = null;
      localStorage.clear();
      state.profile = [];
      state.loading = false;
    },
  },
//   extraReducers: (builder) => {
//     builder
//       .addCase(profile.pending, (state) => {
//         state.loading = true;
//         state.error = null;
//       })
//       .addCase(profile.fulfilled, (state, { payload }) => {
//         state.loading = false;
//         if (payload.success) {
//           state.token = payload.data.token;
//           localStorage.setItem("userAccess", `Bearer ${payload.data.token}`);
//         }
//       })
//       .addCase(profile.rejected, (state, { payload }) => {
//         state.loading = false;
//         state.error = payload;
//       });

//   }
});

export const { logoutProfile  } = ProfileSlice.actions;
export default ProfileSlice.reducer;
