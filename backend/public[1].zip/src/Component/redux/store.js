import { configureStore } from '@reduxjs/toolkit';
import AuthSlice from './reducers/AuthSlice';

const store = configureStore({
    reducer: {
        authUser: AuthSlice
    }
});

export default store;
