import logo from './logo.svg';
import './App.css';
import Layout from './Component/Layout/Layout';
import 'swiper/swiper-bundle.css'
import LoginForm from './Component/Auth/Login';
import PublicRoute from './Component/router/PublicRouter';
import PrivateRoute from './Component/router/PrivateRouter';
import { Route, Routes, } from 'react-router-dom';
import { BrowserRouter as Router } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import RegistrationForm from './Component/Auth/Registartion';
import store from './Component/redux/store';
import { Provider } from 'react-redux';
import Blog from './Component/Pages/Blog';
import About_us from './Component/Pages/About_us';
import Home from './Component/Pages/Home';
import Contact from './Component/Pages/Conatct';
function App() {

  return (
    <>
      <Provider store={store}>
        <ToastContainer />
        <Router>
          <Layout>
            <Routes>
              <Route path="/" element={
                <PublicRoute><LoginForm /></PublicRoute>
              } />
              <Route path="/login" element={
                <PublicRoute><LoginForm /></PublicRoute>
              } />
              <Route path="/register" element={
                <PublicRoute><RegistrationForm /></PublicRoute>
              } />
              <Route path="/home" element={
                <PublicRoute><Home /></PublicRoute>
              } />
              <Route path="/blog" element={
                <PublicRoute><Blog /></PublicRoute>
              } />
              <Route path="/about_us" element={
                <PublicRoute><About_us /></PublicRoute>
              } />
              <Route path="/contact_us" element={
                <PublicRoute><Contact /></PublicRoute>
              } />
              {/* <Route path="/home" element={
                <PrivateRoute><Home /></PrivateRoute>
              } /> */}
              {/* <Route path="/profile" element={
                <PrivateRoute><Profile /></PrivateRoute>
              } />
              <Route path="*" element={<NoPages />} />  */}
            </Routes>
          </Layout>
        </Router>
      </Provider>
    </>
  )
}


export default App;
