import React, { useState } from "react";

function cn(...classes) {
  return classes.filter(Boolean).join(" ");
}

function Tabs({ children, className, defaultValue = 0, onValueChange }) {
  const [activeIndex, setActiveIndex] = useState(defaultValue);

  // Handle tab change
  const handleChange = (index) => {
    setActiveIndex(index);
    if (onValueChange) onValueChange(index);
  };

  // Expect children: TabsList, TabsContent(s)
  // We'll clone children to provide activeIndex info as needed

  // Separate TabsList and TabsContent children
  let tabsList = null;
  let tabsContents = [];

  React.Children.forEach(children, (child) => {
    if (!React.isValidElement(child)) return;

    if (child.type.displayName === "TabsList") {
      tabsList = React.cloneElement(child, {
        activeIndex,
        onChange: handleChange,
      });
    } else if (child.type.displayName === "TabsContent") {
      tabsContents.push(child);
    }
  });

  return (
    <div data-slot="tabs" className={cn("flex flex-col gap-2", className)}>
      {tabsList}
      <div className="flex-1 outline-none">
        {tabsContents.map((content, idx) =>
          idx === activeIndex
            ? React.cloneElement(content, { key: idx, className: cn("flex-1 outline-none", content.props.className) })
            : null
        )}
      </div>
    </div>
  );
}

function TabsList({ children, className, activeIndex, onChange, ...props }) {
  // We'll clone each TabsTrigger to pass needed props
  const triggers = React.Children.map(children, (child, idx) =>
    React.isValidElement(child)
      ? React.cloneElement(child, {
        isActive: activeIndex === idx,
        onSelect: () => onChange(idx),
        key: idx,
      })
      : child
  );

  return (
    <div
      data-slot="tabs-list"
      className={cn(
        "bg-muted text-muted-foreground inline-flex h-9 w-fit items-center justify-center rounded-lg p-[3px]",
        className
      )}
      {...props}
    >
      {triggers}
    </div>
  );
}
TabsList.displayName = "TabsList";

function TabsTrigger({ children, isActive, onSelect, className, ...props }) {
  return (
    <button
      type="button"
      data-slot="tabs-trigger"
      aria-selected={isActive}
      role="tab"
      onClick={onSelect}
      className={cn(
        "text-foreground dark:text-muted-foreground inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap transition-[color,box-shadow] focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        isActive
          ? "bg-background dark:data-[state=active]:text-foreground dark:border-input dark:bg-input/30 shadow-sm"
          : "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring",
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
TabsTrigger.displayName = "TabsTrigger";

function TabsContent({ children, className, ...props }) {
  return (
    <div data-slot="tabs-content" role="tabpanel" className={className} {...props}>
      {children}
    </div>
  );
}
TabsContent.displayName = "TabsContent";

export { Tabs, TabsList, TabsTrigger, TabsContent };
